package com.example.demo.Controller;


import com.example.demo.entities.Screen;
import com.example.demo.services.ScreenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/screen")
public class AdminController {

    @Autowired
    private ScreenService screenService;

    @PostMapping
    public ResponseEntity<Screen> addScreen(@RequestBody Screen screen) {
        Screen createdScreen = screenService.addScreen(screen);
        return new ResponseEntity<>(createdScreen, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Screen> updateScreen(@PathVariable Long id, @RequestBody Screen screen) {
        screen.setId(id);
        Screen updatedScreen = screenService.updateScreen(screen);
        return new ResponseEntity<>(updatedScreen, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteScreen(@PathVariable Long id) {
        screenService.deleteScreen(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
