package com.example.demo.services;


import com.example.demo.entities.Screen;
import com.example.demo.repositories.ScreenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ScreenService {

    @Autowired
    private ScreenRepository screenRepository;

    public Screen addScreen(Screen screen) {
        return screenRepository.save(screen);
    }

    public Screen updateScreen(Screen screen) {
        return screenRepository.save(screen);
    }

    public void deleteScreen(Long id) {
        screenRepository.deleteById(id);
    }
}
