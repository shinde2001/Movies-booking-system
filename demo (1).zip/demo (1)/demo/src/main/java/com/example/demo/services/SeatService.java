package com.example.demo.services;


import com.example.demo.entities.Screen;
import com.example.demo.entities.Seat;
import com.example.demo.repositories.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatService {

    @Autowired
    private SeatRepository seatRepository;

    public List<Seat> getSeatsByScreen(Screen screen) {
        return seatRepository.findByScreen(screen);
    }

    public void updateSeat(Seat seat) {
        seatRepository.save(seat);
    }

    public void releaseLockedSeats(Screen screen) {
        List<Seat> seats = screen.getSeats();
        for (Seat seat : seats) {
            if (seat.isBooked()) {
                seat.setBooked(false);
                seatRepository.save(seat);
            }
        }
    }
}
