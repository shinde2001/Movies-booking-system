package com.example.demo.services;


import com.example.demo.entities.Booking;
import com.example.demo.entities.Movie;
import com.example.demo.entities.Seat;
import com.example.demo.entities.User;
import com.example.demo.repositories.BookingRepository;
import com.example.demo.repositories.MovieRepository;
import com.example.demo.repositories.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private SeatRepository seatRepository;

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Booking bookSeats(User user, Movie movie, List<Seat> seats, String showtime, double totalPrice) {
        for (Seat seat : seats) {
            seat.setBooked(true);
            seatRepository.save(seat);
        }
        Booking booking = new Booking();
        booking.setUser(user);
        booking.setMovie(movie);
        booking.setSeats(seats);
        booking.setShowtime(showtime);
        booking.setTotalPrice(totalPrice);
        return bookingRepository.save(booking);
    }
}
