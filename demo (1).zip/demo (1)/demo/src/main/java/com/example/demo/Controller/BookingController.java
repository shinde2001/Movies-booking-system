package com.example.demo.Controller;


import com.example.demo.entities.Booking;
import com.example.demo.entities.Movie;
import com.example.demo.entities.Seat;
import com.example.demo.entities.User;
import com.example.demo.services.BookingService;
import com.example.demo.services.MovieService;
import com.example.demo.services.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private SeatService seatService;

    @Autowired
    private MovieService movieService;

    @GetMapping("/movies")
    public ResponseEntity<List<Movie>> getAllMovies() {
        List<Movie> movies = movieService.getAllMovies();
        return new ResponseEntity<>(movies, HttpStatus.OK);
    }

    @PostMapping("/reserve")
    public ResponseEntity<?> reserveSeats(@RequestParam Long userId, @RequestParam Long movieId, @RequestParam List<Long> seatIds,
                                          @RequestParam String showtime, @RequestParam double totalPrice) {
        User user = new User();
        user.setId(userId); // In a real application, fetch the user from the database

        Optional<Movie> optionalMovie = movieService.getMovieById(movieId);
        if (optionalMovie.isEmpty()) {
            return new ResponseEntity<>("Movie not found", HttpStatus.NOT_FOUND);
        }
        Movie movie = optionalMovie.get();

        List<Seat> seats = seatIds.stream()
                .map(seatId -> {
                    Seat seat = new Seat();
                    seat.setId(seatId);
                    return seat;
                }).collect(Collectors.toList());

        Booking booking = bookingService.bookSeats(user, movie, seats, showtime, totalPrice);

        if (booking != null) {
            return new ResponseEntity<>(booking, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Booking failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}