package com.example.demo.Controller;


import com.example.demo.entities.Screen;
import com.example.demo.entities.Seat;
import com.example.demo.services.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seats")
public class SeatController {

    @Autowired
    private SeatService seatService;

    @GetMapping
    public ResponseEntity<List<Seat>> getSeatsByScreen(@RequestParam Long screenId) {
        Screen screen = new Screen();
        screen.setId(screenId); // In a real application, fetch the screen from the database
        List<Seat> seats = seatService.getSeatsByScreen(screen);
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }
}
