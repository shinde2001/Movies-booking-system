package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.Data;



@Entity
@Data
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int number;
    private boolean booked;

    @ManyToOne
    @JoinColumn(name = "screen_id")
    private Screen screen;
}
